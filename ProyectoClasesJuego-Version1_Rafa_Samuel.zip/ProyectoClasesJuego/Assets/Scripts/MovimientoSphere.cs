using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MovimientoSphere : MonoBehaviour
{
    // Start is called before the first frame update
    public float Speed = 1.0f;
    public float RotationSpeed = 1.0f;
    public float JumpForce = 1.0f;

    private Rigidbody Physis;
    private int contadorPremiosAdquiridos;
    public Text marcador;
    public Text winText;
    private int cantidadTotalPremios;

    void OnTriggerEnter(Collider other) {
            if(other.gameObject.CompareTag("Premio")){
                other.gameObject.SetActive (false);
                contadorPremiosAdquiridos++;
                marcador.text = "Premios: " + contadorPremiosAdquiridos;
            }
            if (contadorPremiosAdquiridos >= cantidadTotalPremios ){
                winText.text ="Ganaste. Has encontrado todos los premios. Ahora busca la salida.";
                if(other.gameObject.CompareTag("Salida"))
                     other.gameObject.SetActive (false);
            }
    }

    void Start()
    {
        //Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible =true;

        Physis = GetComponent <Rigidbody>();
        contadorPremiosAdquiridos = 0;
        marcador.text = "Premios: " + contadorPremiosAdquiridos;
        cantidadTotalPremios=8;
        winText.text="";
    }

    // Update is called once per frame
    void Update()
    {
        //movimienot
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        transform.Translate(new Vector3(horizontal, 0.0f, vertical) * Time.deltaTime * Speed);

        //Rotación
        float rotationY = Input.GetAxis("Mouse X");

        transform.Rotate(new Vector3 (0, rotationY * Time.deltaTime * RotationSpeed , 0));
 
        //Salto
        if (Input.GetKeyDown(KeyCode.Space)){
            Physis.AddForce (new Vector3(0,JumpForce,0), ForceMode.Impulse);
        }
    }
}