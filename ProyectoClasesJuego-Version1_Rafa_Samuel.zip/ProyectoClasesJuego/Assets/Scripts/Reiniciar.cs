using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Reiniciar : MonoBehaviour
{

    private Button btnReiniciar;
    // Start is called before the first frame update
    void Start()
    {
        btnReiniciar = GetComponent<Button>();
        btnReiniciar.onClick.AddListener(reiniciar);
       
    }

    // Update is called once per frame
    void Update()
    {
         
    }

    void reiniciar()
    {
        Debug.Log("has pulsado reset!!");
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
